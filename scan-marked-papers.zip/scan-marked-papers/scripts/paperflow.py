#!/usr/bin/env python3
"""Batch frame edits and advance a scan to its next review or preflight boundary."""
import argparse
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path
import sys
from urllib.parse import urlsplit

import paperflow_base as base
import paperflow_upload as upload

ROOT=Path(__file__).resolve().parent


def atomic_json(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.tmp')
    with tmp.open('w') as f:json.dump(data,f,ensure_ascii=False,indent=2)
    os.chmod(tmp,0o600);os.replace(tmp,path)


def source():
    contracts=json.loads((ROOT/'api_contracts.json').read_text())
    for op in contracts['operations']:op.pop('purpose',None)
    workflow=(ROOT/'paperflow_workflow.js').read_text().replace('__CONTRACTS__',json.dumps(contracts,separators=(',',':')))
    return (ROOT/'paperflow.js').read_text().replace('__LEGACY__','('+base.JS+')').replace('__WORKFLOW__','('+workflow+')')


def request_payload(args,action,plan=None,checkpoint=None):
    if checkpoint is None:checkpoint=json.loads(args.checkpoint.read_text()) if args.checkpoint and args.checkpoint.exists() else {}
    if checkpoint and (checkpoint.get('origin')!=args.base_url or args.batch_id and checkpoint.get('batch_id')!=args.batch_id):
        raise ValueError('checkpoint_origin_or_batch_mismatch')
    payload={'action':action,'origin':args.base_url,'batch':args.batch_id,'timeout':args.timeout,
             'interval':args.interval,'checkpoint':checkpoint,'plan':plan,'confirm':getattr(args,'confirm',False),'authorize_sync':getattr(args,'authorize_sync',False)}
    if action=='upload':
        signature=json.dumps([plan['key'],plan['sha256'],plan['fields'],plan.get('scope')],ensure_ascii=False,separators=(',',':'))
        prior=checkpoint.get('upload_receipt')
        if prior and prior.get('signature')!=signature:raise ValueError('upload_plan_changed')
        payload['upload_first_dispatch']=not prior or prior.get('state')=='prepared'
        checkpoint={**checkpoint,'origin':args.base_url,'batch_id':checkpoint.get('batch_id') or args.batch_id,
            'upload_receipt':{**(prior or {}),'key':plan['key'],'sha256':plan['sha256'],'signature':signature,
                'state':'dispatching' if payload['upload_first_dispatch'] else prior['state']}}
        payload['checkpoint']=checkpoint
        if args.checkpoint:atomic_json(args.checkpoint,checkpoint)
    return payload


def execute(args,action,plan=None,checkpoint=None):
    payload=request_payload(args,action,plan,checkpoint)
    script_source=source()
    expression='('+script_source+')('+json.dumps(payload,ensure_ascii=False)+')'
    try:
        code=upload.native_code(script_source,payload,args.file) if action=='upload' else 'async(page)=>await page.evaluate(('+script_source+'),'+json.dumps(payload,ensure_ascii=False)+')'
        result=base.browser(args,code,expression)
    except FileNotFoundError:
        if action=='upload' and payload.get('upload_first_dispatch'):
            payload['checkpoint']['upload_receipt']=None;atomic_json(args.checkpoint,payload['checkpoint'])
        result={'ok':False,'error':{'code':'browser_backend_unavailable','retryable':False,'next_action':'use_emit_script'}}
    except (OSError,subprocess.TimeoutExpired):
        result={'ok':False,'error':{'code':'transport_uncertain','retryable':False,'next_action':'read_state_before_retry'}}
    if args.checkpoint and result.get('checkpoint'):atomic_json(args.checkpoint,result['checkpoint'])
    return result


def compact(data):
    """Keep decision data, not recovery signatures or repeated rich-text payloads."""
    result={k:v for k,v in data.items() if k not in ('checkpoint','calls')}
    calls=data.get('calls',[])
    result['http']={'count':len(calls),'failed':sum(c.get('status',0)>=400 for c in calls),
                    'request_ms_sum':sum(c.get('ms',0) for c in calls)}
    r=dict(result.get('result') or {})
    if isinstance(r.get('review'),dict):
        review=r['review'];r['review']={k:v for k,v in review.items() if k not in ('frames','questions')}
        r['review'].update(frame_count=len(review.get('frames',[])),question_count=len(review.get('questions',[])))
    if 'frames' in r:r['frame_count']=len(r.pop('frames'))
    # Explicit snapshot/evidence commands are saved with --output for selective reads.
    if 'questions' in r:r['question_count']=len(r.pop('questions'))
    if r.get('check'):
        check=dict(r['check']);counts={}
        for issue in check.get('issues',[]):
            key=(issue.get('code'),issue.get('severity'));counts[key]=counts.get(key,0)+1
        check['issues']=[{'code':c,'severity':s,'count':n} for (c,s),n in counts.items()];r['check']=check
    if r.get('operation') and isinstance(r.get('data'),dict):
        def summary(value):
            keep=('id','status','stage','workflow_mode','grading_engine','revision','read_version','frame_revision',
                'catalog_revision','source_pdf_sha256','reference_student_id','total_pages','pages_per_paper',
                'ready','counts','source_version','outcome','error','semester_id','scope','classes','config',
                'progress','task_control','analysis_status','analysis_version','summary','phases','next_cursor')
            data={k:v for k,v in value.items() if k in keep}
            for key in ('students','papers','questions','frames','results','answers','judgments','items'):
                if isinstance(value.get(key),list):
                    data[key+'_count']=len(value[key])
            if isinstance(value.get('items'),list):
                data['items']=[{k:v for k,v in item.items() if k in ('id','name','state','status','stage','counts','local_changed')}
                    for item in value['items'] if isinstance(item,dict)]
            return data
        if r['operation'] not in ('classes','general-options','class-students','recent-selection','recent-classes','sync-options','sync-courses','import-links','correction-item'):
            r['data']=summary(r['data'])
            if isinstance(r.get('readback'),dict):r['readback']=summary(r['readback'])
    result['result']=r
    return result


def render_bundle(metadata,pdf_path,out):
    import pymupdf
    from PIL import Image,ImageDraw
    if hashlib.sha256(pdf_path.read_bytes()).hexdigest()!=metadata.get('source_pdf_sha256'):
        raise ValueError('source_pdf_hash_mismatch')
    out.mkdir(parents=True,exist_ok=True);os.chmod(out,0o700)
    frames=metadata['frames'];start=metadata['reference_start'];count=metadata['pages_per_paper']
    images=[];files=[]
    with pymupdf.open(pdf_path) as doc:
        if start+count>len(doc):raise ValueError('reference_page_out_of_range')
        # Each original page is decoded exactly once; every crop uses that image.
        for relative in range(count):
            pix=doc[start+relative].get_pixmap(matrix=pymupdf.Matrix(2,2))
            image=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
            marked=image.copy();draw=ImageDraw.Draw(marked)
            for f in frames:
                for region in f['regions']:
                    if region['page']!=relative:continue
                    b=region['bbox'];box=(round(b[0]*image.width),round(b[1]*image.height),round(b[2]*image.width),round(b[3]*image.height))
                    draw.rectangle(box,outline='#e00000',width=3)
                    draw.text((box[0]+3,box[1]+3),f['label'],fill='#d00000',stroke_width=1,stroke_fill='white')
                    crop=image.crop(box);crop.thumbnail((600,230));images.append((f['label'],crop))
            path=out/f'reference-page-{relative+1}.png';marked.save(path);files.append(path.name)
    if images:
        sheet=Image.new('RGB',(1240,270*((len(images)+1)//2)),'#eeeeee');draw=ImageDraw.Draw(sheet)
        for i,(label,image) in enumerate(images):
            x=(i%2)*620;y=(i//2)*270;draw.text((x+10,y+5),label,fill='black');sheet.paste(image,(x+10,y+25))
        sheet.save(out/'contact-sheet.png');files.append('contact-sheet.png')
    manifest={**metadata,'reviewed':False,'image_files':files,'decoded_pages':count,'crop_count':len(images)}
    atomic_json(out/'review.json',manifest)
    return {'manifest':str(out/'review.json'),'images':files,'decoded_pages':count,'crops':len(images),'reviewed':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base-url');parser.add_argument('--batch-id')
    parser.add_argument('--batch-url')
    parser.add_argument('--browser-session')
    parser.add_argument('--emit-script',type=Path)
    parser.add_argument('--standalone-script',action='store_true')
    parser.add_argument('--wrapper',default=str(Path.home()/'.codex/skills/playwright/scripts/playwright_cli.sh'))
    base.browser_options(parser)
    parser.add_argument('--timeout',type=int,default=45);parser.add_argument('--interval',type=int,default=5)
    parser.add_argument('--checkpoint',type=Path)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--verbose',action='store_true')
    sub=parser.add_subparsers(dest='action',required=True)
    for name in ('inspect','check','diagnose','usage','access','relogin','roster'):sub.add_parser(name)
    p=sub.add_parser('api-list');p.add_argument('--operation')
    p=sub.add_parser('api-call');p.add_argument('--operation',required=True);p.add_argument('--plan',type=Path)
    for name in ('scope','sync'):
        p=sub.add_parser(name);p.add_argument('--plan',type=Path,required=True)
        if name=='sync':p.add_argument('--authorize-sync',action='store_true')
    for name in ('classes','class-students'):
        p=sub.add_parser(name);p.add_argument('--source',choices=('teaching','general'),default='teaching')
        p.add_argument('--grade');p.add_argument('--subject-id');p.add_argument('--course-id')
        if name=='class-students':p.add_argument('--class-id',required=True)
    p=sub.add_parser('upload');p.add_argument('--file',type=Path,required=True);p.add_argument('--pages-per-paper',type=int,required=True)
    p.add_argument('--key',required=True);p.add_argument('--workflow',choices=('scan','grading'),default='scan')
    p.add_argument('--engine',choices=('llm','xueersi','doubao'),default='llm');p.add_argument('--model',default='qwen3.8-max')
    p.add_argument('--has-answer-paper',action='store_true');p.add_argument('--paper-size',choices=('A4','A3'),default='A4')
    p.add_argument('--orientation',choices=('portrait','landscape'),default='portrait');p.add_argument('--paper-sides',choices=('single','double'),default='single')
    p.add_argument('--full-scan',action='store_true');p.add_argument('--analysis-fast',action='store_true')
    p.add_argument('--scope-plan',type=Path);p.add_argument('--file-input-selector',default='#paperflow-upload')
    p=sub.add_parser('run');p.add_argument('--plan',type=Path)
    p.add_argument('--review-pdf',type=Path);p.add_argument('--review-out',type=Path)
    p.add_argument('--follow',action='store_true');p.add_argument('--max-seconds',type=int,default=600)
    p=sub.add_parser('snapshot');p.add_argument('--output',type=Path,dest='snapshot_output')
    p=sub.add_parser('frames');p.add_argument('--edits',type=Path,required=True);p.add_argument('--confirm',action='store_true')
    p=sub.add_parser('associate');p.add_argument('--plan',type=Path,required=True)
    p=sub.add_parser('review');p.add_argument('--pdf',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--metadata',type=Path)
    p=sub.add_parser('retry-precut');p.add_argument('--page',type=int,required=True);p.add_argument('--frame-revision',required=True)
    p=sub.add_parser('evidence');p.add_argument('--paper-id',required=True);p.add_argument('--question-id',action='append')
    p=sub.add_parser('responses');p.add_argument('--plan',type=Path,required=True)
    p=sub.add_parser('catalog');p.add_argument('--plan',type=Path,required=True)
    p=sub.add_parser('collect');p.add_argument('--result',type=Path,required=True)
    args=parser.parse_args()
    import re
    if args.batch_url:
        link=urlsplit(args.batch_url)
        match=re.fullmatch(r'/exams/([A-Za-z0-9_-]{1,80})(?:/analysis|/papers/[A-Za-z0-9_-]{1,80})?/?',link.path)
        if link.scheme not in ('http','https') or not link.netloc or link.username or link.password or link.fragment or not match:
            parser.error('invalid batch URL')
        origin=link.scheme+'://'+link.netloc
        if (args.base_url and args.base_url.rstrip('/')!=origin) or (args.batch_id and args.batch_id!=match[1]):
            parser.error('batch URL conflicts with origin or batch id')
        args.base_url=origin;args.batch_id=match[1]
    args.base_url=(args.base_url or base.DEFAULT_ORIGIN).rstrip('/')
    if args.action=='api-list':
        contracts=json.loads((ROOT/'api_contracts.json').read_text())
        if args.operation:contracts['operations']=[o for o in contracts['operations'] if o['name']==args.operation]
        print(json.dumps(contracts,ensure_ascii=False));return 0 if contracts['operations'] else 1
    batch_optional=args.action in ('upload','classes','class-students','access','relogin','api-call','collect')
    if not args.batch_id and not batch_optional:parser.error('batch-id or batch-url required')
    args.batch_id=args.batch_id or ''
    if args.action=='upload' and not args.checkpoint:parser.error('upload requires checkpoint')
    if not args.browser_session and not args.emit_script and args.action!='collect' and not (args.action=='review' and args.metadata):parser.error('browser-session required for browser backend')
    if args.emit_script and args.action in ('review','collect'):parser.error('emit-script requires a browser action')
    url=urlsplit(args.base_url)
    if url.scheme not in ('http','https') or not url.netloc or url.path or url.username or url.password or url.query or url.fragment:
        parser.error('base-url must be an origin')
    import re
    if args.batch_id and not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',args.batch_id):parser.error('invalid batch id')
    if not 1<=args.timeout<=180 or not 2<=args.interval<=30:parser.error('invalid timeout/interval')
    if args.action=='run' and bool(args.review_pdf)!=bool(args.review_out):parser.error('review-pdf and review-out must be provided together')
    if args.action=='run' and not 1<=args.max_seconds<=3600:parser.error('max-seconds 1..3600')
    try:
        plan_path=getattr(args,'plan',None) or getattr(args,'edits',None)
        plan=json.loads(plan_path.read_text()) if plan_path else None
        if args.action=='api-call':plan={**(plan or {}),'operation':args.operation}
        if args.action in ('classes','class-students'):
            plan={k:getattr(args,k) for k in ('source','grade','subject_id','course_id') if getattr(args,k) is not None}
            if args.action=='class-students':plan['class_id']=args.class_id
        if args.action=='upload':plan=upload.plan(args)
        if args.action=='retry-precut':plan={'page':args.page,'frame_revision':args.frame_revision}
        if args.action=='evidence':plan={'paper_id':args.paper_id,'question_ids':args.question_id}
        if args.emit_script:
            payload=request_payload(args,args.action,plan)
            engine_source=source();engine_id='__paperflow_'+hashlib.sha256(engine_source.encode()).hexdigest()[:20]
            args.emit_script.parent.mkdir(parents=True,exist_ok=True)
            engine_info={}
            if args.standalone_script:
                script='('+engine_source+')('+json.dumps(payload,ensure_ascii=False)+')'
            else:
                engine_file=args.emit_script.with_name('paperflow-engine-'+engine_id.removeprefix('__paperflow_')+'.js')
                bootstrap='(()=>{if(location.origin!=='+json.dumps(args.base_url)+')return {ok:false,error:{code:"origin_mismatch"}};Object.defineProperty(globalThis,'+json.dumps(engine_id)+',{value:('+engine_source+'),configurable:true});return {ok:true,result:{outcome:"engine_loaded",engine_id:'+json.dumps(engine_id)+'}};})()'
                engine_file.write_text(bootstrap,encoding='utf-8');os.chmod(engine_file,0o600)
                script='(async()=>{const input='+json.dumps(payload,ensure_ascii=False)+';const engine=globalThis['+json.dumps(engine_id)+'];if(typeof engine!=="function"){const checkpoint={origin:input.origin,batch_id:input.batch,...input.checkpoint};if(input.action==="upload"&&input.upload_first_dispatch&&checkpoint.upload_receipt?.state==="dispatching")checkpoint.upload_receipt={...checkpoint.upload_receipt,state:"prepared"};return {ok:false,error:{code:"engine_not_loaded",next_action:"evaluate_bootstrap_file"},calls:[],checkpoint};}return await engine(input);})()'
                engine_info={'engine_file':str(engine_file),'engine_id':engine_id,'engine_load_required_if_missing':True}
            args.emit_script.write_text(script,encoding='utf-8');os.chmod(args.emit_script,0o600)
            emitted={'ok':True,'result':{'outcome':'browser_script_created',
                'script_file':str(args.emit_script),'origin':args.base_url,'batch_id':args.batch_id,
                **engine_info,'script_bytes':len(script.encode()),'executed':False,'submitted':False}}
            if args.output:atomic_json(args.output,emitted)
            print(json.dumps(emitted,ensure_ascii=False))
            return 0
        started=time.monotonic()
        if args.action=='review' and args.metadata:
            metadata=json.loads(args.metadata.read_text())
            if isinstance(metadata,dict) and isinstance(metadata.get('result'),dict):metadata=metadata['result']
            if isinstance(metadata,dict) and isinstance(metadata.get('review'),dict):metadata=metadata['review']
            if not isinstance(metadata,dict) or metadata.get('batch_id')!=args.batch_id:
                raise ValueError('review_batch_mismatch')
            data={'ok':True,'result':metadata}
        elif args.action=='collect':
            data=json.loads(args.result.read_text())
            if not isinstance(data,dict) or type(data.get('ok')) is not bool:
                raise ValueError('invalid_browser_result')
            cp=data.get('checkpoint')
            if not isinstance(cp,dict) or cp.get('origin')!=args.base_url or (args.batch_id and cp.get('batch_id')!=args.batch_id):
                raise ValueError('checkpoint_origin_or_batch_mismatch')
            if args.checkpoint:atomic_json(args.checkpoint,cp)
        else:
            data=execute(args,'snapshot' if args.action=='review' else args.action,plan)
        if args.action=='run' and args.follow:
            calls=list(data.get('calls',[]));transitions=list(data.get('transitions',[]))
            while data.get('ok') and data.get('result',{}).get('outcome')=='waiting' and time.monotonic()-started<args.max_seconds:
                if data['result'].get('waiting_for') in ('grading','grading_stop','task_stop'):
                    time.sleep(min(args.interval,max(0,args.max_seconds-(time.monotonic()-started))))
                if time.monotonic()-started>=args.max_seconds:break
                print(json.dumps({'outcome':'waiting','analysis_status':data['result'].get('analysis_status'),
                                  'elapsed_seconds':round(time.monotonic()-started,1)},ensure_ascii=False),file=sys.stderr,flush=True)
                data=execute(args,'run',plan,data.get('checkpoint'))
                calls.extend(data.get('calls',[]));transitions.extend(data.get('transitions',[]))
            data['calls']=calls;data['transitions']=transitions
            data['follow_seconds']=round(time.monotonic()-started,3)
            data['wall_seconds']=round(time.monotonic()-started,3)
        if args.action=='run' and args.review_pdf and data.get('ok') and data['result'].get('review'):
            data['result']['review_bundle']=render_bundle(data['result']['review'],args.review_pdf,args.review_out)
        if args.action=='review' and data.get('ok'):data['result']=render_bundle(data['result'],args.pdf,args.out)
        if args.action=='snapshot' and args.snapshot_output and data.get('ok'):
            atomic_json(args.snapshot_output,data['result']);data['snapshot_file']=str(args.snapshot_output)
    except Exception as exc:
        data={'ok':False,'error':{'code':str(exc) if isinstance(exc,ValueError) and str(exc).replace('_','').isalnum() else 'local_execution_failed'}}
    if args.output:
        atomic_json(args.output,data)
    shown=data if args.verbose else compact(data)
    if args.output:shown={**shown,'output_file':str(args.output)}
    print(json.dumps(shown,ensure_ascii=False))
    return 0 if data.get('ok') else 1


if __name__=='__main__':sys.exit(main())
